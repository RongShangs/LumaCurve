package top.rongshangs.lumacurve.refactor;

import android.os.Looper;
import java.lang.reflect.*;
import java.util.*;
import de.robv.android.xposed.*;

/** Optional post-hook of verified OEM deadlines. Ring buffers, lux thresholds and animations stay OEM. */
final class ResponseTuning {
    static final Set<Class<?>> installed=new HashSet<>();
    static void install(ClassLoader loader){
        List<XC_MethodHook.Unhook> hooks=new ArrayList<>();
        try{
            Class<?> abc=Class.forName("com.android.server.display.AutomaticBrightnessController",false,loader);
            if(installed.contains(abc))return;
            for(String field:new String[]{"mBrighteningLightDebounceConfig","mDarkeningLightDebounceConfig"})
                if(HookEntry.field(abc,field).getType()!=long.class)throw new IllegalStateException("debounce field ABI");
            if(HookEntry.field(abc,"mAmbientBrighteningThreshold").getType()!=float.class)throw new IllegalStateException("threshold ABI");
            Method idle=abc.getDeclaredMethod("isInIdleMode");idle.setAccessible(true);
            if(idle.getReturnType()!=boolean.class)throw new IllegalStateException("idle ABI");
            Method[] methods={abc.getDeclaredMethod("nextAmbientLightBrighteningTransition",long.class),abc.getDeclaredMethod("nextAmbientLightBrighteningTransition",long.class,float.class),abc.getDeclaredMethod("nextAmbientLightDarkeningTransition",long.class)};
            for(Method method:methods){
                if(method.getReturnType()!=long.class)throw new IllegalStateException("deadline ABI");
                final boolean brighten=method.getName().contains("Brightening");
                hooks.add(XposedBridge.hookMethod(method,new XC_MethodHook(){protected void afterHookedMethod(MethodHookParam p){
                    if(p.hasThrowable())return;
                    synchronized(HookEntry.states){for(HookRuntime state:HookEntry.states.values()){
                        if(state.closed||(!state.responseEnabled&&!state.smallResponseEnabled&&!state.lowLightEnabled)||!state.phase.equals("active")||!state.appliesToUser()||Looper.myLooper()!=state.handler.getLooper())continue;
                        try{
                            Object impl=HookEntry.get(state.owner,"mAutomaticBrightnessControllerImpl");
                            if(HookEntry.get(impl,"mAutomaticBrightnessController")!=p.thisObject)continue;
                            if(!((Boolean)state.kernel.get("mUseAutoBrightness"))){state.assistGate.release("inactive");return;}
                            if((Boolean)idle.invoke(p.thisObject)){state.assistGate.release("inactive");return;}
                            boolean small=brighten&&p.args.length==2&&(Float)p.args[1]<((Number)HookEntry.get(p.thisObject,"mAmbientBrighteningThreshold")).floatValue();
                            float candidate=p.args.length==2?(Float)p.args[1]:state.mainCandidate(p.thisObject,impl);
                            boolean guard=state.lowLightApplies(p.thisObject,impl,candidate),custom=(small?state.smallResponseEnabled:state.responseEnabled)&&state.normalTuningAllowed(p.thisObject,impl);
                            if(!guard&&!custom){state.assistGate.release("inactive");return;}
                            long base=((Number)HookEntry.get(p.thisObject,small?"mSmallBrighteningLightDebounceConfig":brighten?"mBrighteningLightDebounceConfig":"mDarkeningLightDebounceConfig")).longValue();
                            long chosen=custom?(small?state.smallBrightenDelay:brighten?state.brightenDelay:state.darkenDelay):base;
                            long horizon=((Number)HookEntry.get(p.thisObject,"mAmbientLightHorizonLong")).longValue();
                            long additional=brighten?0:((Number)HookEntry.get(p.thisObject,"mStepModeDarkenDebounceConfig")).longValue();
                            // OEM night-driving time is added to every main deadline. Keep it and
                            // include it in the retained-history budget; never shorten a native wait.
                            if((Boolean)impl.getClass().getMethod("getDrivingStatus").invoke(impl)){
                                long night=((Number)impl.getClass().getMethod("getNightDrivingDebounceConfig").invoke(impl)).longValue();
                                if(night<0||night>60000||additional<0||additional>60000)return;
                                additional=Math.addExact(additional,night);
                            }
                            if(custom){long safe=AdvancedPolicy.retainedDelay(chosen,base,horizon,additional);if(safe!=chosen)state.delayWindowClamps++;chosen=safe;}
                            if(guard){long existing=Math.max(base,chosen);
                                long wanted=LowLightPolicy.chosen(existing,brighten,false,state.lowLightBrighten,state.lowLightDarken);
                                chosen=LowLightPolicy.withinWindow(wanted,existing,horizon,additional);if(chosen!=wanted)state.delayWindowClamps++;
                            }
                            if(small)state.lastMainSmall=chosen;else if(brighten)state.lastMainBrighten=chosen;else {state.lastMainDarken=chosen;state.lastMainExtra=additional;}
                            long deadline=chosen==base?(Long)p.getResult():DelayPolicy.deadline((Long)p.getResult(),(Long)p.args[0],base,chosen);
                            if(brighten&&state.assistGate.enabled)deadline=LowLightAssistEvidence.deadline(state,p.thisObject,impl,(Long)p.args[0],deadline,p.args.length==2?(Float)p.args[1]:HookRuntime.optionalNumber(p.thisObject,"mAmbientBrighteningThreshold"));
                            if(deadline!=(Long)p.getResult()){p.setResult(deadline);state.responseAdjustments++;if(small)state.smallResponseAdjustments++;if(guard)state.lowLightMainAdjustments++;}return;
                        }catch(Throwable incompatible){return;}
                    }}
                }}));
            }
            installed.add(abc);
        }catch(Throwable incompatible){for(XC_MethodHook.Unhook hook:hooks)hook.unhook();XposedBridge.log("LumaCurve response tuning unavailable: "+incompatible);}
    }
    static boolean supported(Object owner){try{Object impl=HookEntry.get(owner,"mAutomaticBrightnessControllerImpl"),abc=HookEntry.get(impl,"mAutomaticBrightnessController");return abc!=null&&installed.contains(abc.getClass())&&impl.getClass().getMethod("getDrivingStatus").getReturnType()==boolean.class&&HookEntry.field(abc.getClass(),"mAmbientLightHorizonLong").getType()==int.class&&HookEntry.field(abc.getClass(),"mStepModeDarkenDebounceConfig").getType()==long.class;}catch(Throwable absent){return false;}}
    static boolean smallSupported(Object owner){try{Object impl=HookEntry.get(owner,"mAutomaticBrightnessControllerImpl"),abc=HookEntry.get(impl,"mAutomaticBrightnessController");return supported(owner)&&HookEntry.field(abc.getClass(),"mSmallBrighteningLightDebounceConfig").getType()==long.class;}catch(Throwable absent){return false;}}
}
