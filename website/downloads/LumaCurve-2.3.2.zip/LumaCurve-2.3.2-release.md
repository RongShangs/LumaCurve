# HyperLux 2.3.2

版本代码 **23107**，构建 **release-2.3.2**。这是从 2.3.1 主线继续的补丁版，沿用包名、签名约定、HyperOS 4 + Root + LSPosed 运行边界和 GPL-3.0 许可。

## 本次调整

- 亮屏期间继续依赖 Xiaomi 显示控制器已经注册的光感事件。收到环境光事件后立即运行既有判断，保持环境变化的反应速度。
- 刚亮屏或显示策略切换后的 2 秒内，模块健康检查暂时使用 250ms 间隔；稳定亮屏恢复 30 秒检查。连续上报型传感器使用 10 秒检查上限。
- 息屏、AOD、Doze 或 ScreenOff 输出策略生效时，释放暗光锁定监听与模块定时任务；恢复交互并确认自动亮度输出后重新接入。
- `HookRuntime.screenOn()` 同时核对显示状态、`PowerManager.isInteractive()` 和输出策略，避免 HyperOS 在 AOD 阶段仍返回 `ON` 时误把 AOD 当作普通亮屏。
- 状态广播在屏幕状态变化时立即排队发布，详细读数增加采样阶段、健康检查间隔、事件驱动标志和亮屏观察剩余时间。

## 顺滑度与功耗边界

本版没有新增自定义亮度动画、连续背光写入或独立轮询线程。亮度目标仍由 HyperOS 原生滤波、迟滞、亮暗确认、RampAnimator、温控和省电策略推进。模块只调整自己的监听生命周期和健康检查调度，因此不会用模块动画覆盖系统渐变。

本机 `tcs3760` 主光感和辅助光感均为 `on-change` 传感器。`SensorManager.registerListener` 的参数不能被解释为硬件扫描频率控制；本版能够确定的是减少模块回调、计时器和状态处理，不能承诺改变传感器芯片或 Xiaomi sensorservice 的功耗。实际省电幅度需要在目标固件上用相同亮屏/AOD场景做 A/B 测量。

## 验证范围

- `tests/refactor_brightness_control.py`：183 个 Java 服务双测试用例通过，包含传感器监听、亮屏/AOD边界、手动接管回滚和新采样策略。
- 构建时会继续执行现有 Refactor、原生资产、配置、状态传输和面板事务回归。
- 本说明不把主机测试当作真实 Android Hook 或长期功耗测试；安装后应在目标 HyperOS 4 固件上观察 `sampling_phase`、`sampling_health_ms`、`sampling_event_driven` 和事件年龄。

## 安装

安装 `HyperLux-2.3.2.apk`，在 LSPosed 中启用系统框架作用域，然后重启手机。覆盖安装要求与此前版本相同的维护者签名；自行构建的 APK 使用本地签名，只能全新安装。详细读数应显示 `build=release-2.3.2`、`version=2.3.2`。

完整源码与恢复工具随 `LumaCurve-2.3.2-source.zip`、`LumaCurve-2.3.2.zip` 发布。项目按 [GNU GPL-3.0](../../LICENSE) 开源；源码包不包含签名私钥、私有固件或设备采集资料。
