window.LumaCurveUpdate({"version":"1.0.0","versionCode":10000,"zipUrl":"https://lc.rongshangs.top/downloads/luma_curve-1.0.0.zip","changelog":"https://lc.rongshangs.top/#download"});
