/* Standalone site: local assets, responsive layout, accessible curve demo and downloads. */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {pathToFileURL}=require('node:url'),crypto=require('node:crypto');
const pw=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const root=path.resolve(__dirname,'..'),site=path.resolve(root,'../web');
async function main(){
 const browser=await pw.chromium.launch({headless:true,executablePath:process.env.BROWSER_EXECUTABLE});
 const checks=[],errors=[];
 try{
  const page=await browser.newPage({viewport:{width:1440,height:1000}});page.on('pageerror',e=>errors.push(String(e)));
  await page.goto(pathToFileURL(path.join(site,'index.html')).href);await page.waitForFunction(()=>document.getElementById('demo-line').getAttribute('points'));
  assert.equal(await page.title(),'LumaCurve 流光亮度 · 让屏幕随环境平稳调节');checks.push('Standalone local HTML loads with local assets');
  assert.equal(await page.locator('header .author').count(),0);assert.equal(await page.locator('main>.author').count(),1);assert.ok(await page.locator('main>.author').evaluate(el=>el.previousElementSibling.id==='download'));checks.push('Author introduction is below downloads at the bottom');
  assert.equal(await page.locator('.mechanism-grid article').count(),8);assert.equal(await page.locator('.anchor-table-wrap tbody tr').count(),7);checks.push('Full scene, curve, learning, transition and protection mechanisms plus fourteen default anchors');
  assert.deepEqual(await page.locator('.thanks li').allInnerTexts(),['戒戒\n喵喵喵？','Starshine\n好歹露个脸']);
  const update=JSON.parse(fs.readFileSync(path.join(site,'update.json'),'utf8'));
  assert.equal(update.zipUrl,'https://lc.rongshangs.top/downloads/luma_curve-1.0.0.zip');
  assert.match(fs.readFileSync(path.join(site,'update.js'),'utf8'),/LumaCurveUpdate/);
  checks.push('Thanks list and matching static module/WebUI update endpoints are present');
  assert.match(await page.locator('.resource-stats').innerText(),/9.4/);assert.match(await page.locator('.resource-stats').innerText(),/65–71/);assert.match(await page.locator('.resource-measurement').innerText(),/1.26%/);checks.push('Resource figures use measured PSS and single-core CPU');
  assert.equal((await page.locator('#demo-line').getAttribute('points')).split(' ').length,201);
  await page.locator('#demo-lux').fill('0');assert.match(await page.locator('#demo-output').innerText(),/^0 lux · 2.00%$/);
  await page.locator('#demo-lux').fill('1000');assert.match(await page.locator('#demo-output').innerText(),/100,000 lux · 90.00%/);checks.push('Curve demo uses 201 complete samples and truthful default endpoints');
  for(const width of [360,390,768,1440]){await page.setViewportSize({width,height:900});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));}checks.push('No horizontal overflow on four phone/tablet/desktop sizes');
  const localLinks=await page.locator('[href],[src]').evaluateAll(nodes=>nodes.map(n=>n.getAttribute('href')||n.getAttribute('src')).filter(s=>s&&!s.startsWith('#')&&!s.startsWith('https://')));
  for(const target of localLinks){assert.ok(fs.existsSync(path.resolve(site,target)),target);assert.ok(fs.existsSync(path.resolve(root,'website',target)),'repository website missing '+target);}checks.push('Both website and web directories contain every local asset, license and module/source download');
  assert.equal(await page.locator('.hero .actions a').first().getAttribute('href'),'#download');
  await page.locator('.hero .actions a').first().click();
  await page.waitForFunction(()=>{const box=document.getElementById('download').getBoundingClientRect();return location.hash==='#download'&&box.top<innerHeight&&box.bottom>0;});checks.push('Hero download button navigates to the visible download section');
  for (const selector of ['.download-actions a[download]']) {
    const links=page.locator(selector);
    for(let i=0;i<await links.count();i++) {
      const pending=page.waitForEvent('download');await links.nth(i).click();const download=await pending;
      assert.equal(await download.failure(),null);const file=await download.path();
      assert.equal(crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'),crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'dist',download.suggestedFilename()))).digest('hex'));
    }
  }checks.push('Real browser downloads from both module/source buttons complete with matching bytes');
  const sums=fs.readFileSync(path.join(site,'downloads/SHA256SUMS.txt'),'utf8');
  for(const line of sums.trim().split(/\r?\n/)){const [digest,name]=line.split('  ');for(const folder of [path.join(site,'downloads'),path.join(root,'website/downloads'),path.join(root,'dist')])assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(folder,name))).digest('hex'),digest);}checks.push('Both deploy directories contain module/source downloads matching dist and SHA-256');
  assert.equal(await page.locator('script[src^="http"]').count(),0);assert.equal(await page.locator('link[href^="http"][rel="stylesheet"]').count(),0);checks.push('No network JS, CSS, fonts, frameworks or device bridge');
  await page.setViewportSize({width:1440,height:1000});await page.screenshot({path:path.join(root,'build/website-desktop.png'),fullPage:true});
  await page.setViewportSize({width:390,height:844});await page.locator('#demo-lux').fill('401');await page.screenshot({path:path.join(root,'build/website-mobile.png'),fullPage:true});
  assert.deepEqual(errors,[]);checks.push('Desktop/mobile screenshots rendered without JavaScript errors');
  const source_sha256={};for(const name of ['website/index.html','website/assets/site.css','website/assets/site.js','website/assets/icon.svg','website/assets/curve_math.js','tools/sync_website.py','tools/package_source.py','tests/website.cjs'])source_sha256[name]=crypto.createHash('sha256').update(fs.readFileSync(path.join(root,name))).digest('hex');
  fs.writeFileSync(path.join(root,'build/website-verification.json'),JSON.stringify({ok:true,checks,source_sha256,website:site,hosted:false},null,2));console.log(JSON.stringify({ok:true,checks:checks.length}));
 }finally{await browser.close();}
}
main().catch(e=>{console.error(e);process.exitCode=1;});
